package com.example.mcvoice

/** Cola de audio (mic + voces de amigos) que llega desde la página y se mezcla en la grabación. */
object Pcm {
    private val ring = ShortArray(44100 * 2)
    private var r = 0
    private var w = 0
    private var count = 0

    @Synchronized fun clear() { r = 0; w = 0; count = 0 }

    @Synchronized fun put(src: ShortArray, n: Int) {
        for (i in 0 until n) {
            if (count == ring.size) { r = (r + 1) % ring.size; count-- }
            ring[w] = src[i]; w = (w + 1) % ring.size; count++
        }
    }

    @Synchronized fun take(dst: ShortArray, n: Int): Int {
        if (count > 22050) {                    // mantener la latencia baja (~0.2 s)
            val drop = count - 8820
            r = (r + drop) % ring.size; count -= drop
        }
        val m = minOf(n, count)
        for (i in 0 until m) { dst[i] = ring[r]; r = (r + 1) % ring.size }
        count -= m
        return m
    }
}
