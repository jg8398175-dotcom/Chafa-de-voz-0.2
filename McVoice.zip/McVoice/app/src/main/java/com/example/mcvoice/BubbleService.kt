package com.example.mcvoice

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Burbuja flotante.
 *  - Toque corto: alterna Normal <-> "Ellos no me oyen".
 *  - Mantener presionada: abre un menú con los 3 modos.
 *  - Arrastrar: moverla.
 * Mientras se graba, la burbuja y el menú se marcan FLAG_SECURE para que no salgan en el video.
 */
class BubbleService : Service() {
    companion object {
        var instance: BubbleService? = null
        @Volatile var mode = 1
        private const val BASE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var density = 1f
    private val main = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hidePanel() }

    private fun secureFlag(): Int = if (RecorderService.running) WindowManager.LayoutParams.FLAG_SECURE else 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        density = resources.displayMetrics.density
        val d = density
        val size = (58 * d).toInt()
        val tv = TextView(this).apply { gravity = Gravity.CENTER; textSize = 24f }
        lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or secureFlag(), PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (220 * d).toInt() }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        var moved = false; var longPressed = false
        val longRun = Runnable { longPressed = true; showPanel() }
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    moved = false; longPressed = false
                    main.postDelayed(longRun, 500)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (Math.abs(dx) > 12 * d || Math.abs(dy) > 12 * d) {
                        moved = true
                        main.removeCallbacks(longRun)
                    }
                    if (moved) { lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longRun)
                    if (e.action == MotionEvent.ACTION_UP && !moved && !longPressed) MainActivity.runJs("toggleMute()")
                }
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        refresh()
    }

    private fun showPanel() {
        hidePanel()
        val d = density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2262A2F")); cornerRadius = 14 * d
                setStroke((2 * d).toInt(), Color.parseColor("#3A3F45"))
            }
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
        }
        val labels = listOf("🎤  Normal", "🔇  Ellos no me oyen", "🙉  Yo no los oigo")
        labels.forEachIndexed { i, t ->
            val m = i + 1
            val item = TextView(this).apply {
                text = t; textSize = 16f; setTextColor(Color.WHITE)
                setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
            }
            if (BubbleService.mode == m) {
                item.background = GradientDrawable().apply { setColor(Color.parseColor("#3D7524")); cornerRadius = 10 * d }
            }
            item.setOnClickListener {
                MainActivity.runJs("applyMode($m)")
                BubbleService.mode = m
                refresh()
                hidePanel()
            }
            box.addView(item)
        }
        if (RecorderService.running) {                       // pausar / reanudar la grabación
            val pItem = TextView(this).apply {
                text = if (RecorderService.paused) "▶  Reanudar grabación" else "⏸  Pausar grabación"
                textSize = 16f; setTextColor(Color.WHITE)
                setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
            }
            pItem.background = GradientDrawable().apply { setColor(Color.parseColor("#9A6B0A")); cornerRadius = 10 * d }
            pItem.setOnClickListener {
                val np = !RecorderService.paused
                RecorderService.paused = np
                MainActivity.runJs("syncPause($np)")
                refresh()
                hidePanel()
            }
            box.addView(pItem, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() })
        }
        val onRight = lp.x > resources.displayMetrics.widthPixels / 2
        val plp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or secureFlag(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (onRight) maxOf(0, lp.x - (230 * d).toInt()) else lp.x + (66 * d).toInt()
            y = lp.y
        }
        box.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) hidePanel()
            false
        }
        try {
            wm.addView(box, plp)
            panel = box
            main.postDelayed(hideRun, 6000)
        } catch (e: Exception) { }
    }

    private fun hidePanel() {
        main.removeCallbacks(hideRun)
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    fun refresh() {
        main.post {
            val tv = bubble ?: return@post
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(when (mode) {
                    2 -> Color.parseColor("#555B61")
                    3 -> Color.parseColor("#B06A1D")
                    else -> Color.parseColor("#3D7524")
                })
                if (RecorderService.running) setStroke((4 * density).toInt(), Color.parseColor(if (RecorderService.paused) "#E0A21B" else "#D8392B"))
            }
            tv.background = bg
            tv.text = when (mode) {
                2 -> "🔇"
                3 -> "🙉"
                else -> "🎤"
            }
            val want = BASE_FLAGS or secureFlag()
            if (lp.flags != want) {
                lp.flags = want
                runCatching { wm.updateViewLayout(tv, lp) }
            }
        }
    }

    override fun onDestroy() {
        instance = null
        hidePanel()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        super.onDestroy()
    }
}
