package com.example.mcvoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    companion object {
        var web: WebView? = null
        fun runJs(code: String) { web?.post { web?.evaluateJavascript(code, null) } }
    }

    private lateinit var webView: WebView
    private var pendingPerm: PermissionRequest? = null

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val p = pendingPerm; pendingPerm = null
        if (p != null) { if (ok) p.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else p.deny() }
    }
    private val recPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) launchProjection() else runJs("onRecState(false)")
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            startForegroundService(
                Intent(this, RecorderService::class.java).putExtra("code", r.resultCode).putExtra("data", r.data)
            )
            runJs("onRecState(true)")
        } else runJs("onRecState(false)")
    }
    private val overlay = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { setupChain() }
    private val battery = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { setupChain() }

    private var wantBubble = false
    private var askedBattery = false
    private var askedOverlay = false

    /** Lleva al usuario directo a los ajustes: 1) sin restricción de batería, 2) mostrar sobre otras apps, 3) burbuja. */
    private fun setupChain() {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !askedBattery) {
            askedBattery = true
            toast("Toca \"Permitir\" para que MC Voice siga activa en segundo plano")
            try {
                battery.launch(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                battery.launch(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            return
        }
        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            toast("Activa \"Mostrar sobre otras apps\" para MC Voice")
            overlay.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (wantBubble) {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, BubbleService::class.java))
            else toast("Sin el permiso de superposición no se puede mostrar la burbuja")
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun launchProjection() {
        if (Build.VERSION.SDK_INT >= 34) toast("Elige \"Una sola app\" y selecciona Minecraft: así la burbuja no sale en el video")
        projection.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }

    inner class Bridge {
        @JavascriptInterface fun startRecording() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchProjection()
            else recPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
        @JavascriptInterface fun stopRecording() = runOnUiThread {
            stopService(Intent(this@MainActivity, RecorderService::class.java))
        }
        @JavascriptInterface fun showBubble() = runOnUiThread { wantBubble = true; setupChain() }
        @JavascriptInterface fun setupBackground() = runOnUiThread { askedBattery = false; askedOverlay = false; setupChain() }
        @JavascriptInterface fun hideBubble() = runOnUiThread {
            wantBubble = false
            stopService(Intent(this@MainActivity, BubbleService::class.java))
        }
        @JavascriptInterface fun voiceService(on: Boolean) = runOnUiThread {
            val i = Intent(this@MainActivity, VoiceService::class.java)
            try {
                if (!on) stopService(i)
                else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    startForegroundService(i)
            } catch (e: Exception) { toast("No se pudo mantener el chat en segundo plano") }
        }
        @JavascriptInterface fun setState(mode: Int) {
            BubbleService.mode = mode
            BubbleService.instance?.refresh()
        }
        @JavascriptInterface fun setPaused(p: Boolean) { RecorderService.paused = p }
        @JavascriptInterface fun pushAudio(b64: String) {
            if (!RecorderService.running || RecorderService.paused) return
            try {
                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                val shorts = ShortArray(bytes.size / 2)
                java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
                Pcm.put(shorts, shorts.size)
            } catch (e: Exception) { }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(0xFF1D2024.toInt())
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(r.url)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(req: PermissionRequest) {
                    runOnUiThread {
                        if (!req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { req.deny(); return@runOnUiThread }
                        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                            req.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        else { pendingPerm = req; micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                    }
                }
            }
        }
        web = webView
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        // Atrás = mandar a segundo plano (no cerrar la sala)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { moveTaskToBack(true) }
        })
    }

    // Que el WebView siga activo (micrófono y sala) cuando sales a Minecraft
    override fun onPause() { super.onPause(); webView.resumeTimers() }
    override fun onStop() { super.onStop(); webView.resumeTimers() }

    override fun onDestroy() {
        if (isFinishing) {
            stopService(Intent(this, BubbleService::class.java))
            stopService(Intent(this, VoiceService::class.java))
            web = null
        }
        super.onDestroy()
    }
}
